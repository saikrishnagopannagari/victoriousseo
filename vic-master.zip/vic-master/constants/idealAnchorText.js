module.exports = [
  {
    url: "https://docstation.co/solutions/pharmacies",
    idealAnchorText: "pharmacy software",
  },
  {
    url: "https://docstation.co/features/billing-revenue",
    idealAnchorText: "pharmacy billing",
  },
  {
    url: "https://docstation.co/features/clinical-intelligence",
    idealAnchorText: "pharmacy data analytics",
  },
  {
    url: "https://docstation.co/features/value-based-pharmacy",
    idealAnchorText: "value based care pharmacy",
  },
];
