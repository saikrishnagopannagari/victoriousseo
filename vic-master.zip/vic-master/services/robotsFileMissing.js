const crawler = require("./crawler");
const robotsFileMissing = async (URL, page) => {
  let { response, text, title } = await crawler(URL + "/robots.txt", page);
  if (
    !String(response.status())[0] === ("2" || "3") ||
    title.includes("404" || "400")
  ) {
    return "Robots.txt is not accessible";
  } else {
    return "Robots.txt is accessible";
  }
};

module.exports = robotsFileMissing;
