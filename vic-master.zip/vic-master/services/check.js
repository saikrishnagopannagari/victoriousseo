const stringSimilarity = require("string-similarity");
console.log(stringSimilarity.compareTwoStrings("hello", "hello"));
