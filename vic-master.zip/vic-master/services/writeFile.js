const fs = require("fs");
const { format } = require("@fast-csv/format");

const writeFile = async (fileName, data) => {
  return new Promise(function (resolve, reject) {
    const stream = format({ headers: true });
    const csvFile = fs.createWriteStream(fileName);
    stream.pipe(csvFile);
    for (i = 0; i <= data.length; i++) {
      stream.write(data[i]);
    }
    stream.end();
    resolve(true);
  });
};

module.exports = writeFile;
