const crawler = async (LINK, page) => {
  const response = await page.goto(LINK);
  const text = await response.text();
  const title = await page.title();
  return { response, text, title };
};

module.exports = crawler;
