const getFileContents = require("./getFileContents");
const models = require("../models");
const writeFile = require("./writeFile");
const gooddURLS = require("../constants/goodURLs");
const selectedColumns = [
  "source",
  "destination",
  "anchor",
  "status_code",
  "type",
];
const parsed = (array) =>
  array.map((o) =>
    selectedColumns.reduce((acc, curr) => {
      acc[curr] = o[curr];
      return acc;
    }, {})
  );
const siteErrors = async (timestamp, URL, DOMAIN_NAME) => {
  // let [clientError, serverError] = await Promise.all([
  //   getFileContents("./sf_output/client_error_(4xx)_inlinks.csv"),
  //   getFileContents("./sf_output/server_error_(5xx)_inlinks.csv"),
  // ]);
  let [clientError, serverError] = await Promise.all([
    models.sf_mm_client_error_4xx_inlinks.findAll({
      where: { company_url: URL, createdat: timestamp },
      raw: true,
    }),
    models.sf_mm_server_error_5xx_inlinks.findAll({
      where: { company_url: URL, createdat: timestamp },
      raw: true,
    }),
  ]);
  clientError = parsed(clientError);
  serverError = parsed(serverError);
  let errors = [...clientError, ...serverError];
  errors = errors.filter(
    (o) => o.destination.includes(DOMAIN_NAME) && gooddURLS.includes(o.source)
  );

  errors.forEach(
    (o) => (o.solution = "Update Broken Link on Source URL or Remove")
  );
  await writeFile("./output/siteErrors.csv", errors);
  return true;
};
module.exports = siteErrors;
