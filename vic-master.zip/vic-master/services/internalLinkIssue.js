const getFileContents = require("./getFileContents");
const writeFile = require("./writeFile");
const models = require("../models");
const stringSimilarity = require("string-similarity");
const targets = require("../constants/idealAnchorText");
const goodURLs = require("../constants/goodURLs");
const selectedColumns = [
  "source",
  "destination",
  "anchor",
  "ideal_anchor_text",
  "string_Similarity",
];
const parsed = (array) =>
  array.map((o) =>
    selectedColumns.reduce((acc, curr) => {
      acc[curr] = o[curr];
      return acc;
    }, {})
  );
const getInternalLinks = (o) => {
  for (let i = 0; i < targets.length; i++) {
    if (
      o.destination.includes(targets[i].url) &&
      o.type === "Hyperlink" &&
      goodURLs.includes(o.source)
    )
      return true;
  }
  return false;
};
const internalLinkIssue = async (timestamp, URL) => {
  // let inLinks = await getFileContents("./sf_output/all_inlinks.csv");
  let inLinks = await models.sf_mm_all_inlinks.findAll({
    where: { company_url: URL, createdat: timestamp },
    raw: true,
  });
  inLinks = inLinks.filter((o) => getInternalLinks(o));
  inLinks.forEach((o) => {
    targets.forEach((t) => {
      o.destination.includes(t.url)
        ? (o.ideal_anchor_text = t.idealAnchorText)
        : null;
    });
    o.string_Similarity =
      parseInt(
        stringSimilarity.compareTwoStrings(o.ideal_anchor_text, o.anchor) * 100
      ) + "%";
  });
  inLinks = parsed(inLinks);
  await writeFile("./output/internalLinkIssue.csv", inLinks);
};
module.exports = internalLinkIssue;
