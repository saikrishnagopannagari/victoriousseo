const getFileContents = require("./getFileContents");
const writeFile = require("./writeFile");
const models = require("../models");
const goodURLs = require("../constants/goodURLs");
const metaDescriptionErrors = async (timestamp, URL) => {
  // const missingMeta = await getFileContents(
  //   "./output/meta_description_missing.csv"
  // );
  // const duplicateMeta = await getFileContents(
  //   "./output/meta_description_duplicate.csv"
  // );
  // const [missingMeta, duplicateMeta, all] = await Promise.all([
  //   getFileContents("./sf_output/meta_description_missing.csv"),
  //   getFileContents("./sf_output/meta_description_duplicate.csv"),
  //   getFileContents("./sf_output/meta_description_all.csv"),
  // ]);
  const [missingMeta, duplicateMeta, all] = await Promise.all([
    models.sf_mm_meta_description_missing.findAll({
      where: { company_url: URL, createdat: timestamp },
      raw: true,
    }),
    models.sf_mm_meta_description_duplicate.findAll({
      where: { company_url: URL, createdat: timestamp },
      raw: true,
    }),
    models.sf_mm_meta_description_all.findAll({
      where: { company_url: URL, createdat: timestamp },
      raw: true,
    }),
  ]);
  missingMeta.forEach((o) => (o.missing_meta = true));
  duplicateMeta.forEach((o) => (o.duplicate_meta = true));
  // const all = await getFileContents("./output/meta_description_all.csv");
  const metaTooShort = all.filter(
    (o) =>
      Number(o.meta_description_1_length) < 70 &&
      Number(o.meta_description_1_length) > 0
  );
  metaTooShort.forEach((o) => (o.meta_too_short = true));
  const metaTooLong = all.filter(
    (o) => Number(o.meta_description_1_length) > 155
  );
  metaTooLong.forEach((o) => (o.meta_too_long = true));

  let metas = [
    ...duplicateMeta,
    ...missingMeta,
    ...metaTooShort,
    ...metaTooLong,
  ];
  const urls = [];
  const parsedMeta = [];

  metas.forEach((meta) => {
    if (urls.includes(meta.url)) {
      parsedMeta.forEach((parsed, index) => {
        if (parsed.url === meta.url) {
          parsedMeta[index] = { ...parsed, ...meta };
        }
      });
    } else {
      urls.push(meta.url);
      parsedMeta.push(meta);
    }
  });
  metas.forEach((meta) => {
    if (!meta.missing_meta) meta.missing_meta = false;
    if (!meta.duplicate_meta) meta.duplicate_meta = false;
    if (!meta.meta_too_short) meta.meta_too_short = false;
    if (!meta.meta_too_long) meta.meta_too_long = false;
  });

  metas = metas.filter((o) => goodURLs.includes(o.address));

  await writeFile("./output/metaDescriptionErrors.csv", metas);
  return true;
};
module.exports = metaDescriptionErrors;
