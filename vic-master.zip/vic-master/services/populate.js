const models = require("../models");
const fsPromise = require("fs").promises;
const getFileContents = require("./getFileContents");
let data;
let oldColumns;
let newColumns;
let values = [];
let columnsLen;
let table;
const populate = async (url, timestamp) => {
  return new Promise(async function (resolve, reject) {
    let files = await fsPromise.readdir("./sf_output/");
    for (let file of files) {
      if (file.slice(-3) !== "csv" || file === "crawl_overview.csv") continue;
      data = await getFileContents("./sf_output/" + file);
      if (!data[0]) continue;
      oldColumns = Object.keys(data[0]);
      newColumns = oldColumns.map((column) => {
        return column
          .replace(/[^a-zA-Z0-9]/g, "_")
          .toLocaleLowerCase()
          .replace(/_{2,}/g, "_")
          .replace(/^_/, "")
          .replace(/_$/, "");
      });
      table = file.split(".")[0];
      table = table
        .replace(/[^a-zA-Z0-9]/g, "_")
        .toLocaleLowerCase()
        .replace(/_{2,}/g, "_")
        .replace(/^_/, "")
        .replace(/_$/, "");
      table = "sf_mm_" + table;
      data = data.map((row) => Object.values(row));
      columnsLen = newColumns.length;
      data.forEach((row) => {
        let obj = {};
        for (let i = 0; i < columnsLen; i++) {
          obj[newColumns[i]] = row[i];
        }
        values.push(obj);
      });
      values = values.map((v) => ({
        ...v,
        createdat: timestamp,
        company_url: url,
      }));
      console.log(table, values.length);
      if (table === "sf_mm_internal_html") console.log(values[0]);
      await models[table].bulkCreate(values);
      values = [];
    }
    resolve(true);
  });
};
// (async () => {
//   populate(
//     "https://www.sfgate.com/business/article/How-to-get-started-with-SF-Gate-Business-Insider-Program-0",
//     "2020-01-01"
//   );
// })();
module.exports = populate;
