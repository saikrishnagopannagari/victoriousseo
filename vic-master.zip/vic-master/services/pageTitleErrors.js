const getFileContents = require("./getFileContents");
const writeFile = require("./writeFile");
const models = require("../models");
const goodURLs = require("../constants/goodURLs");
const pageTitleErrors = async (timestamp, URL) => {
  // const [missingTitles, duplicateTitles, all] = await Promise.all([
  //   getFileContents("./sf_output/page_titles_missing.csv"),
  //   getFileContents("./sf_output/page_titles_duplicate.csv"),
  //   getFileContents("./sf_output/page_titles_all.csv"),
  // ]);
  const [missingTitles, duplicateTitles, all] = await Promise.all([
    models.sf_mm_page_titles_missing.findAll({
      where: { company_url: URL, createdat: timestamp },
      raw: true,
    }),
    models.sf_mm_page_titles_duplicate.findAll({
      where: { company_url: URL, createdat: timestamp },
      raw: true,
    }),
    models.sf_mm_page_titles_all.findAll({
      where: { company_url: URL, createdat: timestamp },
      raw: true,
    }),
  ]);
  missingTitles.forEach((o) => (o.missing_title = true));
  duplicateTitles.forEach((o) => (o.duplicate_title = true));
  // const all = await getFileContents("./output/page_titles_all.csv");
  const titleTooShort = all.filter(
    (o) => Number(o.title_1_length) < 30 && Number(o.title_1_length) > 0
  );
  titleTooShort.forEach((o) => (o.title_too_short = true));
  const titleTooLong = all.filter((o) => Number(o.title_1_length) > 60);
  titleTooLong.forEach((o) => (o.title_too_long = true));

  let titles = [
    ...duplicateTitles,
    ...missingTitles,
    ...titleTooShort,
    ...titleTooLong,
  ];
  const urls = [];
  const parsedTitles = [];

  titles.forEach((title) => {
    if (urls.includes(title.url)) {
      parsedTitles.forEach((parsed, index) => {
        if (parsed.url === title.url) {
          parsedTitles[index] = { ...parsed, ...title };
        }
      });
    } else {
      urls.push(title.url);
      parsedTitles.push(title);
    }
  });
  titles.forEach((title) => {
    if (!title.missing_title) title.missing_title = false;
    if (!title.duplicate_title) title.duplicate_title = false;
    if (!title.title_too_short) title.title_too_short = false;
    if (!title.title_too_long) title.title_too_long = false;
  });
  titles = titles.filter((o) => goodURLs.includes(o.address));
  await writeFile("./output/pageTitleErrors.csv", titles);
  return true;
};
module.exports = pageTitleErrors;
