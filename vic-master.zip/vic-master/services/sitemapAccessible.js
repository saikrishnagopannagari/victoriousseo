const crawler = require("./crawler");
const sitemapAccessible = async (URL, page) => {
  let { response, text, title } = await crawler(URL + "/sitemap.xml", page);

  if (
    !String(response.status())[0] === ("2" || "3") ||
    title.includes("404" || "400" || "500")
  ) {
    return "Sitemap.xml is not accessible";
  } else {
    return "Sitemap.xml is accessible";
  }
};

module.exports = sitemapAccessible;
