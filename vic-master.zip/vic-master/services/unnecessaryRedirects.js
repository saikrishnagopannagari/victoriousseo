const getFileContents = require("./getFileContents");
const writeFile = require("./writeFile");
const models = require("../models");
let goodURLs = require("../constants/goodURLs");
goodURLs.forEach((o) => {
  goodURLs.push(o + "/");
});
console.log(goodURLs);
const selectedColumns = [
  "source",
  "address",
  "final_address",
  "anchor_text",
  "redirect_type_1",
  "status_code_1",
];
const parsed = (array) =>
  array.map((o) =>
    selectedColumns.reduce((acc, curr) => {
      acc[curr] = o[curr];
      return acc;
    }, {})
  );
const unnecessaryRedirects = async (timestamp, URL, DOMAIN_NAME) => {
  // let redirects = await getFileContents("./sf_output/redirects.csv")
  let redirects = await models.sf_mm_redirects.findAll({
    where: { company_url: URL, createdat: timestamp },
    raw: true,
  });
  redirects = redirects.filter(
    (o) => o.address.includes(DOMAIN_NAME) && goodURLs.includes(o.source)
  );
  redirects = parsed(redirects);
  redirects.forEach(
    (o) => (o.solution = "Update link on Source URL so it points to Final URL")
  );
  console.log(redirects);
  await writeFile("./output/unnecessaryRedirects.csv", redirects);
};
module.exports = unnecessaryRedirects;
