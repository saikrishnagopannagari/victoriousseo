const path = require("path");
const csv = require("fast-csv");
const fs = require("fs");
const getFileContents = async (filepath) => {
  const data = [];
  return new Promise(function (resolve, reject) {
    fs.createReadStream(filepath)
      .pipe(csv.parse({ headers: true }))
      .on("error", (error) => reject(error))
      .on("data", (row) => {
        for (let key in row) {
          if (row[key] === "") row[key] = null;
        }
        data.push(row);
      })
      .on("end", async (rowCount) => {
        resolve(data);
      });
  });
};

module.exports = getFileContents;
