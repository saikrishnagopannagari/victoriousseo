const pageCanonicalization = async (DOMAIN_NAME, page) => {
  await page.goto("https://" + DOMAIN_NAME);
  const link1 = await page.url();
  await page.goto("http://" + DOMAIN_NAME);
  const link2 = await page.url();
  await page.goto("https://www." + DOMAIN_NAME);
  const link3 = await page.url();
  await page.goto("http://www." + DOMAIN_NAME);
  const link4 = await page.url();
  await page.goto("https://" + DOMAIN_NAME + "/");
  const link5 = await page.url();
  await page.goto("http://" + DOMAIN_NAME + "/");
  const link6 = await page.url();
  await page.goto("https://www." + DOMAIN_NAME + "/");
  const link7 = await page.url();
  await page.goto("http://www." + DOMAIN_NAME + "/");
  const link8 = await page.url();
  if (
    link1 === link2 &&
    link1 === link3 &&
    link1 === link4 &&
    link1 === link5 &&
    link1 === link6 &&
    link1 === link7 &&
    link1 === link8 &&
    link1 === "https://" + DOMAIN_NAME + "/"
  ) {
    return "Page Canonicalization Issue is not present";
  }
  return "Page Canonicalization Issue is present";
};

module.exports = pageCanonicalization;
