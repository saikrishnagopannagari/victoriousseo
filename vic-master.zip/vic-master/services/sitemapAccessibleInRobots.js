const crawler = require("./crawler");
const sitemapAccessibleInRobots = async (URL, page) => {
  let { response, text, title } = await crawler(URL + "/robots.txt", page);
  if (text.includes("Sitemap:")) {
    return "Sitemap.xml is referenced in robots.txt";
  } else return "Sitemap.xml is not referenced in robots.txt";
};

module.exports = sitemapAccessibleInRobots;
