const getFileContents = require("./getFileContents");
const models = require("../models");
const writeFile = require("./writeFile");
const goodURLs = require("../constants/goodURLs");
const average = (arr) => arr.reduce((p, c) => p + c, 0) / arr.length;
const webPerformance = async (timestamp, URL) => {
  // const performance = await models.sf_mm_internal_html.findAll()
  const selectedColumns = [
    "address",
    "first_contentful_paint_time_ms",
    "time_to_interactive_ms",
    "speed_index_time_ms",
    "total_blocking_time_ms",
    "largest_contentful_paint_time_ms",
    "cumulative_layout_shift",
  ];
  const parsed = (array) =>
    array.map((o) =>
      selectedColumns.reduce((acc, curr) => {
        acc[curr] = o[curr];
        return acc;
      }, {})
    );
  let performance = await models.sf_mm_internal_html.findAll({
    where: { company_url: URL, createdat: timestamp, status_code: 200 },
    raw: true,
  });
  performance = performance.filter(
    (o) => o.content_type.includes("text/html") && goodURLs.includes(o.address)
  );
  const firstContentfulPaintTime = average(
    performance
      .filter((o) => o.first_contentful_paint_time_ms !== null)
      .map((o) => o.first_contentful_paint_time_ms / 1000)
  );
  const timeToInteractive = average(
    performance
      .filter((o) => o.time_to_interactive_ms !== null)
      .map((o) => o.time_to_interactive_ms / 1000)
  );
  const speedIndexTime = average(
    performance
      .filter((o) => o.speed_index_time_ms !== null)
      .map((o) => o.speed_index_time_ms / 1000)
  );
  const totalBlockingTime = average(
    performance
      .filter((o) => o.total_blocking_time_ms !== null)
      .map((o) => Number(o.total_blocking_time_ms))
  );
  const largestContentfulPaintTime = average(
    performance
      .filter((o) => o.largest_contentful_paint_time_ms !== null)
      .map((o) => o.largest_contentful_paint_time_ms / 1000)
  );
  const cumulativeLayoutShift = average(
    performance
      .filter((o) => o.cumulative_layout_shift !== null)
      .map((o) => Number(o.cumulative_layout_shift))
  );

  performance = parsed(performance);
  performance.push({
    first_contentful_paint_time_ms: "average-seconds",
    time_to_interactive_ms: "average-seconds",
    speed_index_time_ms: "average-seconds",
    total_blocking_time_ms: "average",
    largest_contentful_paint_time_ms: "average-seconds",
    cumulative_layout_shift: "average",
  });
  performance.push({
    first_contentful_paint_time_ms: firstContentfulPaintTime,
    time_to_interactive_ms: timeToInteractive,
    speed_index_time_ms: speedIndexTime,
    total_blocking_time_ms: totalBlockingTime,
    largest_contentful_paint_time_ms: largestContentfulPaintTime,
    cumulative_layout_shift: cumulativeLayoutShift,
  });
  await writeFile("./output/webPerformanceIssue.csv", performance);

  return {
    firstContentfulPaintTime,
    timeToInteractive,
    speedIndexTime,
    totalBlockingTime,
    largestContentfulPaintTime,
    cumulativeLayoutShift,
  };
};
module.exports = webPerformance;
