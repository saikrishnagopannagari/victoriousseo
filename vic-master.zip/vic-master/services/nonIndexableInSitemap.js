const getFileContents = require("./getFileContents");
const models = require("../models");
const nonIndexableInSitemap = async (timestamp, URL) => {
  // const data = await getFileContents("./sf_output/sitemaps_all.csv");
  const data = await models.sf_mm_sitemaps_all.findAll({
    where: { company_url: URL, createdat: timestamp },
    raw: true,
  });
  const nonIndexableUrls = [];
  data.forEach((row) => {
    if (row.indexability == "Non-Indexable") {
      nonIndexableUrls.push(row.address);
    }
  });
  return nonIndexableUrls;
};
module.exports = nonIndexableInSitemap;
