var DataTypes = require("sequelize").DataTypes;
var _sf_mm_all_image_inlinks = require("./sf_mm_all_image_inlinks");
var _sf_mm_all_inlinks = require("./sf_mm_all_inlinks");
var _sf_mm_canonicals_canonicalised = require("./sf_mm_canonicals_canonicalised");
var _sf_mm_canonicals_missing = require("./sf_mm_canonicals_missing");
var _sf_mm_canonicals_multiple = require("./sf_mm_canonicals_multiple");
var _sf_mm_client_error_4xx_inlinks = require("./sf_mm_client_error_4xx_inlinks");
var _sf_mm_content_all = require("./sf_mm_content_all");
var _sf_mm_directives_nofollow = require("./sf_mm_directives_nofollow");
var _sf_mm_directives_noindex = require("./sf_mm_directives_noindex");
var _sf_mm_external_all = require("./sf_mm_external_all");
var _sf_mm_h1_all = require("./sf_mm_h1_all");
var _sf_mm_hreflang_inconsistent_language_return_links = require("./sf_mm_hreflang_inconsistent_language_return_links");
var _sf_mm_hreflang_missing = require("./sf_mm_hreflang_missing");
var _sf_mm_hreflang_missing_return_links = require("./sf_mm_hreflang_missing_return_links");
var _sf_mm_hreflang_no_index_return_links = require("./sf_mm_hreflang_no_index_return_links");
var _sf_mm_hreflang_non200_hreflang_urls = require("./sf_mm_hreflang_non200_hreflang_urls");
var _sf_mm_hreflang_non_canonical_return_links = require("./sf_mm_hreflang_non_canonical_return_links");
var _sf_mm_hreflang_unlinked_hreflang_urls = require("./sf_mm_hreflang_unlinked_hreflang_urls");
var _sf_mm_images_missing_alt_text_inlinks = require("./sf_mm_images_missing_alt_text_inlinks");
var _sf_mm_internal_all = require("./sf_mm_internal_all");
var _sf_mm_internal_html = require("./sf_mm_internal_html");
var _sf_mm_javascript_all = require("./sf_mm_javascript_all");
var _sf_mm_meta_description_all = require("./sf_mm_meta_description_all");
var _sf_mm_meta_description_duplicate = require("./sf_mm_meta_description_duplicate");
var _sf_mm_meta_description_missing = require("./sf_mm_meta_description_missing");
var _sf_mm_near_duplicates_report = require("./sf_mm_near_duplicates_report");
var _sf_mm_oversized_images_inlinks = require("./sf_mm_oversized_images_inlinks");
var _sf_mm_page_titles_all = require("./sf_mm_page_titles_all");
var _sf_mm_page_titles_duplicate = require("./sf_mm_page_titles_duplicate");
var _sf_mm_page_titles_missing = require("./sf_mm_page_titles_missing");
var _sf_mm_redirection_javascript_inlinks = require("./sf_mm_redirection_javascript_inlinks");
var _sf_mm_redirection_meta_refresh_inlinks = require("./sf_mm_redirection_meta_refresh_inlinks");
var _sf_mm_redirects = require("./sf_mm_redirects");
var _sf_mm_response_codes_blocked_by_robots_txt = require("./sf_mm_response_codes_blocked_by_robots_txt");
var _sf_mm_search_console_all = require("./sf_mm_search_console_all");
var _sf_mm_server_error_5xx_inlinks = require("./sf_mm_server_error_5xx_inlinks");
var _sf_mm_sitemaps_all = require("./sf_mm_sitemaps_all");
var _sf_mm_sitemaps_nonindexable_urls_in_sitemap = require("./sf_mm_sitemaps_nonindexable_urls_in_sitemap");
var _sf_mm_sitemaps_orphan_urls = require("./sf_mm_sitemaps_orphan_urls");
var _sf_mm_sitemaps_urls_not_in_sitemap = require("./sf_mm_sitemaps_urls_not_in_sitemap");
var _sf_mm_structured_data_error_report = require("./sf_mm_structured_data_error_report");
var _sf_mm_structured_data_missing = require("./sf_mm_structured_data_missing");
var _sf_mm_url_parameters = require("./sf_mm_url_parameters");

function initModels(sequelize) {
  var sf_mm_all_image_inlinks = _sf_mm_all_image_inlinks(sequelize, DataTypes);
  var sf_mm_all_inlinks = _sf_mm_all_inlinks(sequelize, DataTypes);
  var sf_mm_canonicals_canonicalised = _sf_mm_canonicals_canonicalised(sequelize, DataTypes);
  var sf_mm_canonicals_missing = _sf_mm_canonicals_missing(sequelize, DataTypes);
  var sf_mm_canonicals_multiple = _sf_mm_canonicals_multiple(sequelize, DataTypes);
  var sf_mm_client_error_4xx_inlinks = _sf_mm_client_error_4xx_inlinks(sequelize, DataTypes);
  var sf_mm_content_all = _sf_mm_content_all(sequelize, DataTypes);
  var sf_mm_directives_nofollow = _sf_mm_directives_nofollow(sequelize, DataTypes);
  var sf_mm_directives_noindex = _sf_mm_directives_noindex(sequelize, DataTypes);
  var sf_mm_external_all = _sf_mm_external_all(sequelize, DataTypes);
  var sf_mm_h1_all = _sf_mm_h1_all(sequelize, DataTypes);
  var sf_mm_hreflang_inconsistent_language_return_links = _sf_mm_hreflang_inconsistent_language_return_links(sequelize, DataTypes);
  var sf_mm_hreflang_missing = _sf_mm_hreflang_missing(sequelize, DataTypes);
  var sf_mm_hreflang_missing_return_links = _sf_mm_hreflang_missing_return_links(sequelize, DataTypes);
  var sf_mm_hreflang_no_index_return_links = _sf_mm_hreflang_no_index_return_links(sequelize, DataTypes);
  var sf_mm_hreflang_non200_hreflang_urls = _sf_mm_hreflang_non200_hreflang_urls(sequelize, DataTypes);
  var sf_mm_hreflang_non_canonical_return_links = _sf_mm_hreflang_non_canonical_return_links(sequelize, DataTypes);
  var sf_mm_hreflang_unlinked_hreflang_urls = _sf_mm_hreflang_unlinked_hreflang_urls(sequelize, DataTypes);
  var sf_mm_images_missing_alt_text_inlinks = _sf_mm_images_missing_alt_text_inlinks(sequelize, DataTypes);
  var sf_mm_internal_all = _sf_mm_internal_all(sequelize, DataTypes);
  var sf_mm_internal_html = _sf_mm_internal_html(sequelize, DataTypes);
  var sf_mm_javascript_all = _sf_mm_javascript_all(sequelize, DataTypes);
  var sf_mm_meta_description_all = _sf_mm_meta_description_all(sequelize, DataTypes);
  var sf_mm_meta_description_duplicate = _sf_mm_meta_description_duplicate(sequelize, DataTypes);
  var sf_mm_meta_description_missing = _sf_mm_meta_description_missing(sequelize, DataTypes);
  var sf_mm_near_duplicates_report = _sf_mm_near_duplicates_report(sequelize, DataTypes);
  var sf_mm_oversized_images_inlinks = _sf_mm_oversized_images_inlinks(sequelize, DataTypes);
  var sf_mm_page_titles_all = _sf_mm_page_titles_all(sequelize, DataTypes);
  var sf_mm_page_titles_duplicate = _sf_mm_page_titles_duplicate(sequelize, DataTypes);
  var sf_mm_page_titles_missing = _sf_mm_page_titles_missing(sequelize, DataTypes);
  var sf_mm_redirection_javascript_inlinks = _sf_mm_redirection_javascript_inlinks(sequelize, DataTypes);
  var sf_mm_redirection_meta_refresh_inlinks = _sf_mm_redirection_meta_refresh_inlinks(sequelize, DataTypes);
  var sf_mm_redirects = _sf_mm_redirects(sequelize, DataTypes);
  var sf_mm_response_codes_blocked_by_robots_txt = _sf_mm_response_codes_blocked_by_robots_txt(sequelize, DataTypes);
  var sf_mm_search_console_all = _sf_mm_search_console_all(sequelize, DataTypes);
  var sf_mm_server_error_5xx_inlinks = _sf_mm_server_error_5xx_inlinks(sequelize, DataTypes);
  var sf_mm_sitemaps_all = _sf_mm_sitemaps_all(sequelize, DataTypes);
  var sf_mm_sitemaps_nonindexable_urls_in_sitemap = _sf_mm_sitemaps_nonindexable_urls_in_sitemap(sequelize, DataTypes);
  var sf_mm_sitemaps_orphan_urls = _sf_mm_sitemaps_orphan_urls(sequelize, DataTypes);
  var sf_mm_sitemaps_urls_not_in_sitemap = _sf_mm_sitemaps_urls_not_in_sitemap(sequelize, DataTypes);
  var sf_mm_structured_data_error_report = _sf_mm_structured_data_error_report(sequelize, DataTypes);
  var sf_mm_structured_data_missing = _sf_mm_structured_data_missing(sequelize, DataTypes);
  var sf_mm_url_parameters = _sf_mm_url_parameters(sequelize, DataTypes);


  return {
    sf_mm_all_image_inlinks,
    sf_mm_all_inlinks,
    sf_mm_canonicals_canonicalised,
    sf_mm_canonicals_missing,
    sf_mm_canonicals_multiple,
    sf_mm_client_error_4xx_inlinks,
    sf_mm_content_all,
    sf_mm_directives_nofollow,
    sf_mm_directives_noindex,
    sf_mm_external_all,
    sf_mm_h1_all,
    sf_mm_hreflang_inconsistent_language_return_links,
    sf_mm_hreflang_missing,
    sf_mm_hreflang_missing_return_links,
    sf_mm_hreflang_no_index_return_links,
    sf_mm_hreflang_non200_hreflang_urls,
    sf_mm_hreflang_non_canonical_return_links,
    sf_mm_hreflang_unlinked_hreflang_urls,
    sf_mm_images_missing_alt_text_inlinks,
    sf_mm_internal_all,
    sf_mm_internal_html,
    sf_mm_javascript_all,
    sf_mm_meta_description_all,
    sf_mm_meta_description_duplicate,
    sf_mm_meta_description_missing,
    sf_mm_near_duplicates_report,
    sf_mm_oversized_images_inlinks,
    sf_mm_page_titles_all,
    sf_mm_page_titles_duplicate,
    sf_mm_page_titles_missing,
    sf_mm_redirection_javascript_inlinks,
    sf_mm_redirection_meta_refresh_inlinks,
    sf_mm_redirects,
    sf_mm_response_codes_blocked_by_robots_txt,
    sf_mm_search_console_all,
    sf_mm_server_error_5xx_inlinks,
    sf_mm_sitemaps_all,
    sf_mm_sitemaps_nonindexable_urls_in_sitemap,
    sf_mm_sitemaps_orphan_urls,
    sf_mm_sitemaps_urls_not_in_sitemap,
    sf_mm_structured_data_error_report,
    sf_mm_structured_data_missing,
    sf_mm_url_parameters,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
