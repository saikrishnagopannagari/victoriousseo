const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_response_codes_blocked_by_robots_txt', {
    address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    inlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    matched_robots_txt_line: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_response_codes_blocked_by_robots_txt',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_response_codes_blocked_by_robots_txt_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
