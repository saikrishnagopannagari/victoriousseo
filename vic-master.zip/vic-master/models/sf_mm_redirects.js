const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_redirects', {
    chain_type: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    number_of_redirects: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    loop: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    },
    source: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    temp_redirect_in_chain: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    },
    address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    final_address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    final_indexability: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    final_indexability_status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    final_content: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    final_status_code: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    final_status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    alt_text: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    anchor_text: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    link_path: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    link_position: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code_1: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    status_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_2: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code_2: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_2: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type_2: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url_2: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_3: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code_3: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_3: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type_3: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url_3: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_4: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code_4: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_4: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type_4: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url_4: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_5: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code_5: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_5: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type_5: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url_5: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_6: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code_6: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_6: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type_6: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url_6: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_7: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code_7: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_7: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type_7: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url_7: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_8: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code_8: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_8: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type_8: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url_8: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_9: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code_9: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_9: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type_9: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url_9: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_10: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code_10: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_10: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type_10: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url_10: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_redirects',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_redirects_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
