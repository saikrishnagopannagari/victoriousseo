const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_url_parameters', {
    address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_type: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    indexability: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    indexability_status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    hash: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    length: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    canonical_link_element_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    url_encoded_address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_url_parameters',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_url_parameters_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
