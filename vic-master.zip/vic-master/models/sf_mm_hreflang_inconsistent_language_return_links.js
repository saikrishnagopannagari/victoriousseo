const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_hreflang_inconsistent_language_return_links', {
    url_with_inconsistent_language_return_link: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    url_target: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    url_returning_with_inconsistent_language: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    expected_language: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    actual_language: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_hreflang_inconsistent_language_return_links',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_hreflang_inconsistent_language_return_links_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
