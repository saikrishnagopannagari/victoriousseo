const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_javascript_all', {
    address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    html_word_count: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    rendered_html_word_count: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    word_count_change: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    js_word_count: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    html_title: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    rendered_html_title: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    html_h1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    rendered_html_h1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    html_meta_description: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    rendered_html_meta_description: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    html_canonical: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    rendered_html_canonical: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    unique_inlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_js_inlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_js_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_external_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_external_js_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    html_meta_robots_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    rendered_html_meta_robots_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    pretty_url: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    ugly_url: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_javascript_all',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_javascript_all_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
