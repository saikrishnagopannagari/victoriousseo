const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_internal_html', {
    address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_type: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    indexability: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    indexability_status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    title_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    title_1_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    title_1_pixel_width: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    meta_description_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    meta_description_1_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    meta_description_1_pixel_width: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    meta_keywords_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    meta_keywords_1_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    h1_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    h1_1_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    h1_2: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    h1_2_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    h2_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    h2_1_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    h2_2: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    h2_2_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    meta_robots_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    x_robots_tag_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    meta_refresh_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    canonical_link_element_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    rel_next_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    rel_prev_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    http_rel_next_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    http_rel_prev_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    amphtml_link_element: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    size_bytes: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    word_count: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    text_ratio: {
      type: DataTypes.DOUBLE,
      allowNull: true
    },
    crawl_depth: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    link_score: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    inlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_inlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_js_inlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    of_total: {
      type: DataTypes.DOUBLE,
      allowNull: true
    },
    outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_js_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    external_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_external_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_external_js_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    closest_similarity_match: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    no_near_duplicates: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    spelling_errors: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    grammar_errors: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    hash: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    response_time: {
      type: DataTypes.DOUBLE,
      allowNull: true
    },
    last_modified: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    cookies: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    http_version: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    performance_score: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    first_contentful_paint_time_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    speed_index_time_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    largest_contentful_paint_time_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    time_to_interactive_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    total_blocking_time_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    cumulative_layout_shift: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    total_size_savings_bytes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    total_time_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    total_requests: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    total_page_size_bytes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    html_size_bytes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    html_count: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    image_size_bytes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    image_count: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    css_size_bytes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    css_count: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    javascript_size_bytes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    javascript_count: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    font_size_bytes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    font_count: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    media_size_bytes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    media_count: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    other_size_bytes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    other_count: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    third_party_size_bytes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    third_party_count: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    core_web_vitals_assessment: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    crux_first_contentful_paint_time_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    crux_first_input_delay_time_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    crux_largest_contentful_paint_time_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    crux_cumulative_layout_shift: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    eliminate_render_blocking_resources_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    defer_offscreen_images_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    efficiently_encode_images_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    properly_size_images_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    minify_css_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    minify_javascript_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    reduce_unused_css_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    reduce_unused_javascript_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    serve_images_in_next_gen_formats_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    enable_text_compression_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    preconnect_to_required_origins_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    server_response_times_ttfb__ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    multiple_redirects_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    preload_key_requests_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    use_video_format_for_animated_images_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    total_image_optimization_savings_ms: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    avoid_serving_legacy_javascript_to_modern_browsers_savings_byte: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    image_elements_do_not_have_explicit_width__height: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    avoid_large_layout_shifts: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    url_encoded_address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    crawl_timestamp: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_internal_html',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_internal_html_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
