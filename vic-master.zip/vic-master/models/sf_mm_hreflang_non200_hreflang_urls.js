const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_hreflang_non200_hreflang_urls', {
    type: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    source: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    destination: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    hreflang: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    size_bytes: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    alt_text: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    anchor: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    follow: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    },
    target: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    rel: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    path_type: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    unlinked: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    },
    link_path: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    link_position: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    link_origin: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_hreflang_non200_hreflang_urls',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_hreflang_non200_hreflang_urls_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
