const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_hreflang_missing_return_links', {
    url_missing_return_link: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    url_not_returning_link: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    expected_link: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_hreflang_missing_return_links',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_hreflang_missing_return_links_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
