const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_page_titles_duplicate', {
    address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    occurrences: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    title_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    title_1_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    title_1_pixel_width: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    indexability: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    indexability_status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_page_titles_duplicate',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_page_titles_duplicate_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
