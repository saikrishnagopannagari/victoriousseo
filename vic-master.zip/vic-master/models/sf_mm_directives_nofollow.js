const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_directives_nofollow', {
    address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    occurrences: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    meta_robots_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    x_robots_tag_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    meta_refresh_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    canonical_link_element_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    http_canonical: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_directives_nofollow',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_directives_nofollow_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
