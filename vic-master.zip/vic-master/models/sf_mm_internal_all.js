const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_internal_all', {
    address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    content_type: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status_code: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    indexability: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    indexability_status: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    title_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    title_1_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    title_1_pixel_width: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    meta_description_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    meta_description_1_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    meta_description_1_pixel_width: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    meta_keywords_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    meta_keywords_1_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    h1_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    h1_1_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    h1_2: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    h1_2_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    h2_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    h2_1_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    h2_2: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    h2_2_length: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    meta_robots_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    x_robots_tag_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    meta_refresh_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    canonical_link_element_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    rel_next_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    rel_prev_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    http_rel_next_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    http_rel_prev_1: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    amphtml_link_element: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    size_bytes: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    word_count: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    text_ratio: {
      type: DataTypes.DOUBLE,
      allowNull: true
    },
    crawl_depth: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    link_score: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    inlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_inlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_js_inlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    of_total: {
      type: DataTypes.DOUBLE,
      allowNull: true
    },
    outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_js_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    external_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_external_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    unique_external_js_outlinks: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    closest_similarity_match: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    no_near_duplicates: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    spelling_errors: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    grammar_errors: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    hash: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    response_time: {
      type: DataTypes.DOUBLE,
      allowNull: true
    },
    last_modified: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_url: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    redirect_type: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    cookies: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    http_version: {
      type: DataTypes.DOUBLE,
      allowNull: true
    },
    url_encoded_address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    crawl_timestamp: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_internal_all',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_internal_all_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
