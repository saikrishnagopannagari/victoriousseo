const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('sf_mm_hreflang_non_canonical_return_links', {
    url: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    non_canonical_return_link_url: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    canonical: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    createdat: {
      type: DataTypes.DATE,
      allowNull: true
    },
    company_url: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    sequelize,
    tableName: 'sf_mm_hreflang_non_canonical_return_links',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "sf_mm_hreflang_non_canonical_return_links_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
